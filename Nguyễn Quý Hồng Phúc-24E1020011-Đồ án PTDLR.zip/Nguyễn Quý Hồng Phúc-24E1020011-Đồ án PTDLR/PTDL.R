############################################
# ANALYSIS OF SUI-USDT HOURLY PRICE
# FULL R CODE - READY TO RUN
############################################

# ==============================
# 1. INSTALL & LOAD LIBRARIES
# ==============================
install.packages(c(
  "tidyverse",
  "lubridate",
  "forecast",
  "tseries",
  "TTR",
  "caret",
  "randomForest",
  "ggplot2"
))

library(tidyverse)
library(lubridate)
library(forecast)
library(tseries)
library(TTR)
library(caret)
library(randomForest)
library(ggplot2)

# ==============================
# 2. READ & PREPROCESS DATA
# ==============================
df <- read_csv("D:/COIN/sui_usdt_1h_2years.csv")

df$timestamp <- ymd_hms(df$timestamp)
df <- df %>% arrange(timestamp)

# Overview
glimpse(df)
summary(df)
colSums(is.na(df))

# ==============================
# 3. EXPLORATORY DATA ANALYSIS
# ==============================

# Closing price over time
ggplot(df, aes(timestamp, close)) +
  geom_line(color = "steelblue") +
  labs(
    title = "SUI / USDT Hourly Closing Price",
    x = "Time",
    y = "Price (USDT)"
  ) +
  theme_minimal()

# Price distribution
ggplot(df, aes(close)) +
  geom_histogram(bins = 50, fill = "orange") +
  labs(title = "Distribution of Closing Price")

# Trading volume
ggplot(df, aes(timestamp, volume)) +
  geom_line(color = "darkgreen") +
  labs(title = "Trading Volume Over Time")

# ==============================
# 4. RETURN ANALYSIS
# ==============================

df <- df %>%
  mutate(
    return = log(close / lag(close))
  ) %>%
  drop_na()

# Plot return
ggplot(df, aes(timestamp, return)) +
  geom_line(color = "red") +
  labs(title = "Log Return of SUI")

# ==============================
# 5. STATIONARITY TEST
# ==============================

# ADF test
adf.test(df$close)
adf.test(df$return)

# ==============================
# 6. TECHNICAL INDICATORS
# ==============================

df <- df %>%
  mutate(
    SMA_20 = SMA(close, n = 20),
    EMA_20 = EMA(close, n = 20),
    RSI_14 = RSI(close, n = 14),
    MACD = MACD(close)$macd,
    MACD_signal = MACD(close)$signal
  )

# Plot price with SMA & EMA
ggplot(df, aes(timestamp)) +
  geom_line(aes(y = close), color = "black") +
  geom_line(aes(y = SMA_20), color = "blue") +
  geom_line(aes(y = EMA_20), color = "red") +
  labs(title = "SUI Price with SMA & EMA")

# ==============================
# 7. ARIMA MODEL
# ==============================

# Create time series
ts_close <- ts(df$close, frequency = 24)

# Fit ARIMA
model_arima <- auto.arima(ts_close)
summary(model_arima)

# Forecast next 24 hours
forecast_arima <- forecast(model_arima, h = 24)
autoplot(forecast_arima)

# ==============================
# 8. MACHINE LEARNING MODELS
# ==============================

# Create lag features
df_ml <- df %>%
  mutate(
    lag1 = lag(close, 1),
    lag2 = lag(close, 2),
    lag3 = lag(close, 3)
  ) %>%
  drop_na()

# Train / Test split
set.seed(42)
train_index <- createDataPartition(df_ml$close, p = 0.8, list = FALSE)

train <- df_ml[train_index, ]
test <- df_ml[-train_index, ]

# ------------------------------
# Linear Regression
# ------------------------------
model_lm <- train(
  close ~ lag1 + lag2 + lag3 + volume,
  data = train,
  method = "lm"
)

pred_lm <- predict(model_lm, test)
rmse_lm <- RMSE(pred_lm, test$close)
rmse_lm

# ------------------------------
# Random Forest
# ------------------------------
model_rf <- randomForest(
  close ~ lag1 + lag2 + lag3 + volume,
  data = train,
  ntree = 300
)

pred_rf <- predict(model_rf, test)
rmse_rf <- RMSE(pred_rf, test$close)
rmse_rf

# ==============================
# 9. MODEL COMPARISON
# ==============================

results <- data.frame(
  Model = c("Linear Regression", "Random Forest"),
  RMSE = c(rmse_lm, rmse_rf)
)

print(results)

# ==============================
# 10. CONCLUSION OUTPUT
# ==============================
cat("\nCONCLUSION:\n")
cat("- SUI price is non-stationary\n")
cat("- Return series is stationary\n")
cat("- Random Forest outperforms Linear Regression\n")
cat("- ARIMA suitable for short-term forecasting\n")

############################################
# END OF SCRIPT
############################################
# Sửa lại định dạng ch Looker Studio
# 2. PARSE TIMESTAMP
# ==============================
# 1. Xử lý dữ liệu (giữ nguyên logic của bạn)
df$timestamp <- ymd_hms(df$timestamp, tz = "UTC")

df_daily <- df %>%
  mutate(date = as.Date(timestamp)) %>%
  group_by(date) %>%
  summarise(
    open   = first(open),
    high   = max(high),
    low    = min(low),
    close  = last(close),
    volume = sum(volume),
    .groups = "drop"
  )

# 2. Định dạng ngày chuẩn YYYY-MM-DD
df_daily$date <- format(df_daily$date, "%Y-%m-%d")

# 3. Định dạng số: dùng dấu phẩy cho hàng nghìn và dấu chấm cho thập phân
# Lưu ý: Khi định dạng thế này, các cột số sẽ chuyển thành dạng ký tự (string)
df_formatted <- df_daily %>%
  mutate(across(where(is.numeric), ~ format(., big.mark = ",", decimal.mark = ".", scientific = FALSE)))

# 4. Xuất file CSV
# Dùng write_excel_csv để Excel nhận diện tốt hơn (thường dùng cho báo cáo)
write_excel_csv(df_formatted, "D:/COIN/sui_daily_looker.csv")
# Them cot daily_turn de PTDL trong Looker
library(dplyr)
library(readr)

df <- read_csv("D:/COIN/sui_daily_looker.csv")

df <- df %>%
  arrange(date) %>%
  mutate(
    daily_return = log(close / lag(close))
  )

write_csv(df, "D:/COIN/sui_usdt_daily_return.csv")


