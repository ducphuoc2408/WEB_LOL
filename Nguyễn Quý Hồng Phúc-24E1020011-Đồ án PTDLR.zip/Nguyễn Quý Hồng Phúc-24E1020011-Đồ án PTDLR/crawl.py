import ccxt
import pandas as pd
import time
from datetime import datetime, timedelta

# ===============================
# CONFIG
# ===============================
SYMBOL = 'SUI/USDT'
TIMEFRAME = '1h'
YEARS = 2
LIMIT = 1000          # Binance cho tối đa 1000 nến mỗi lần gọi
SLEEP_TIME = 0.3      # tránh rate limit

# ===============================
# INIT BINANCE
# ===============================
exchange = ccxt.binance({
    'enableRateLimit': True,
    'options': {
        'defaultType': 'spot'
    }
})

# ===============================
# TÍNH THỜI GIAN BẮT ĐẦU (2 NĂM)
# ===============================
end_time = exchange.milliseconds()
start_time = exchange.parse8601(
    (datetime.utcnow() - timedelta(days=365 * YEARS)).strftime('%Y-%m-%dT%H:%M:%S')
)

print("Start:", exchange.iso8601(start_time))
print("End  :", exchange.iso8601(end_time))

# ===============================
# CRAWL DATA
# ===============================
all_ohlcv = []
since = start_time

while since < end_time:
    try:
        ohlcv = exchange.fetch_ohlcv(
            SYMBOL,
            timeframe=TIMEFRAME,
            since=since,
            limit=LIMIT
        )

        if not ohlcv:
            break

        all_ohlcv.extend(ohlcv)
        since = ohlcv[-1][0] + 1  # sang candle tiếp theo

        print(f"Fetched up to {exchange.iso8601(ohlcv[-1][0])}")

        time.sleep(SLEEP_TIME)

    except Exception as e:
        print("Error:", e)
        time.sleep(5)

# ===============================
# CHUYỂN SANG DATAFRAME
# ===============================
df = pd.DataFrame(
    all_ohlcv,
    columns=[
        "timestamp",
        "open",
        "high",
        "low",
        "close",
        "volume"
    ]
)

df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
df.set_index("timestamp", inplace=True)

# ===============================
# LƯU FILE
# ===============================
df.to_csv("sui_usdt_1h_2years.csv")

print("DONE!")
print(df.head())
print(df.tail())
print("Total rows:", len(df))
