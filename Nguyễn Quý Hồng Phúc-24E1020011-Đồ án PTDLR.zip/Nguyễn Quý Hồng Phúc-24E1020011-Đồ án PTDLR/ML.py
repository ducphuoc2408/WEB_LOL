import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
from sklearn.preprocessing import StandardScaler

# ==================================================
# 1. LOAD & SẮP XẾP DỮ LIỆU
# ==================================================
df = pd.read_csv("D:/COIN/sui_usdt_1h_2years.csv")
df["timestamp"] = pd.to_datetime(df["timestamp"])
df = df.sort_values("timestamp").reset_index(drop=True)

# ==================================================
# 2. FEATURE ENGINEERING (NÂNG CAO)
# ==================================================
# Tỷ suất sinh lời log
df["log_return"] = np.log(df["close"] / df["close"].shift(1))

# RSI (Đo lực mua/bán)
def compute_rsi(data, window=14):
    diff = data.diff(1)
    gain = (diff.where(diff > 0, 0)).rolling(window=window).mean()
    loss = (-diff.where(diff < 0, 0)).rolling(window=window).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))

df["rsi"] = compute_rsi(df["close"])

# ATR (Độ biến động thực tế - Giúp nhận diện Sideway)
df['high_low'] = df['high'] - df['low']
df['high_close'] = np.abs(df['high'] - df['close'].shift())
df['low_close'] = np.abs(df['low'] - df['close'].shift())
df['tr'] = df[['high_low', 'high_close', 'low_close']].max(axis=1)
df['atr'] = df['tr'].rolling(14).mean()

# MACD
df["ema_12"] = df["close"].ewm(span=12, adjust=False).mean()
df["ema_26"] = df["close"].ewm(span=26, adjust=False).mean()
df["macd"] = df["ema_12"] - df["ema_26"]

# Volume Change & Lags
df["vol_change"] = df["volume"].pct_change()
df["lag_return_1"] = df["log_return"].shift(1)

# ==================================================
# 3. LABELING (ĐỊNH NGHĨA TĂNG/GIẢM/NGANG)
# ==================================================
# Điều chỉnh ngưỡng threshold này để cân bằng các nhãn
threshold = 0.0025 
df["next_return"] = df["log_return"].shift(-1)

def labeling(x):
    if x > threshold: return 1
    if x < -threshold: return -1
    return 0

df["target"] = df["next_return"].apply(labeling)
df = df.dropna().reset_index(drop=True)

# ==================================================
# 4. CHUẨN BỊ DỮ LIỆU TRAIN/TEST
# ==================================================
features = ["rsi", "atr", "macd", "vol_change", "lag_return_1"]
X = df[features]
y = df["target"]

split = int(len(df) * 0.8)
X_train, X_test = X.iloc[:split], X.iloc[split:]
y_train, y_test = y.iloc[:split], y.iloc[split:]

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# ==================================================
# 5. TRAIN MODEL (DÙNG CLASS_WEIGHT ĐỂ TRỊ NHÃN 0)
# ==================================================
model = RandomForestClassifier(
    n_estimators=200, 
    max_depth=12, 
    class_weight='balanced', # Tự động cân bằng khi nhãn 0 ít hoặc khó học
    random_state=42
)
model.fit(X_train_scaled, y_train)
y_pred = model.predict(X_test_scaled)

# ==================================================
# 6. ĐÁNH GIÁ & TRỰC QUAN HÓA
# ==================================================
print("ACCURACY:", accuracy_score(y_test, y_pred))
print("\nCLASSIFICATION REPORT:")
print(classification_report(y_test, y_pred))

# Vẽ Confusion Matrix
# Sửa lại thứ tự nhãn để ô đúng đi từ góc dưới trái lên trên phải
labels = [-1, 0, 1] 
tick_labels = ['Giảm', 'Ngang', 'Tăng']

cm = confusion_matrix(y_test, y_pred, labels=labels)

plt.figure(figsize=(8,6))
# Sử dụng ax.invert_yaxis() để gốc tọa độ nằm ở dưới cùng bên trái
ax = sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                 xticklabels=tick_labels, 
                 yticklabels=tick_labels)

ax.invert_yaxis() # Đảo ngược trục Y để nhãn -1 nằm ở dưới cùng
plt.title('Ma trận nhầm lẫn (Gốc tọa độ dưới trái)')
plt.ylabel('Thực tế (Actual)')
plt.xlabel('Dự đoán (Predicted)')
plt.show()

# Vẽ Lợi nhuận tích lũy (Backtest giả lập)
backtest_df = pd.DataFrame({
    'actual_return': df.loc[y_test.index, 'next_return'],
    'prediction': y_pred
})
# Chiến thuật: Long nếu đoán 1, Short nếu đoán -1, thoát lệnh nếu đoán 0
backtest_df['strategy_return'] = backtest_df['actual_return'] * backtest_df['prediction']
plt.figure(figsize=(12,6))
plt.plot((1 + backtest_df['actual_return']).cumprod(), label='Market (SUI)', alpha=0.5)
plt.plot((1 + backtest_df['strategy_return']).cumprod(), label='AI Strategy', color='red')
plt.title('So sánh hiệu quả: Chiến thuật AI vs Giữ SUI')
plt.legend()
plt.show()